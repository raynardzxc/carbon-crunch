credit_page <- div(
  titlePanel("Credits"),
  p("This is the credits page"),
  tags$li(a(href = route_link("/"), "Back"))
)